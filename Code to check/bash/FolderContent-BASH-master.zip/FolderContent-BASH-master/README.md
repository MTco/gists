### FolderContent for BASH

-------------------

Script zanechá v adresáři a podadresářích soubor FILES.LST, ve kterém budou názvy všech souborů v daném adresáři. Nulové záznamy budou smazány.

-------------------

Script leaves the file FILES.LST in folder and all subfolders. Contains the list of filenames in that folder. Empty folders will stay empty.

_Jakub Truhlář ©2014_
